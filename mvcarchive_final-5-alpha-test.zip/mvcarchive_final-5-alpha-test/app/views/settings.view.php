<?php
$this->view('header')
?>

<h1 class="text-center">THIS IS SETTINGS PAGE</h1>

<?php
$this->view('footer')
?>
