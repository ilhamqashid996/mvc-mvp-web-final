<?php
require_once __DIR__ . '/test_config.php';

if (!defined('ROOTPATH')) {
    define('ROOTPATH', realpath(__DIR__ . '/../'));
}

require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Model.php'; 
require_once __DIR__ . '/../app/models/User.php';

use PHPUnit\Framework\TestCase;

class LoginTest2Test extends TestCase
{
    protected $userModel;
    
    protected function setUp(): void
    {
        $this->userModel = new \Model\User();
        // Clean up and create table for isolation
        // $this->userModel->run_query("DROP TABLE IF EXISTS users");
        // $this->userModel->create_table();
    }

    public function testLoginSuccessWithCorrectCredentials()
    {
        $email = 'testuser@example.com';
        $password = 'mypassword';
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $this->userModel->insert([
            'username' => 'testuser',
            'email' => $email,
            'password' => $hashedPassword,
            'date' => date('Y-m-d H:i:s')
        ]);

        // Simulate login
        $row = $this->userModel->select_single_row_data(['email' => $email]);
        $this->assertNotFalse($row, 'User should exist');
        $this->assertTrue(password_verify($password, $row->password), 'Password should verify');
    }

    public function testLoginFailsWithIncorrectPassword()
    {
        $email = 'testuser2@example.com';
        $password = 'mypassword';
        $wrongPassword = 'wrongpassword';
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $this->userModel->insert([
            'username' => 'testuser2',
            'email' => $email,
            'password' => $hashedPassword,
            'date' => date('Y-m-d H:i:s')
        ]);

        // Simulate login
        $row = $this->userModel->select_single_row_data(['email' => $email]);
        $this->assertNotFalse($row, 'User should exist');
        $this->assertFalse(password_verify($wrongPassword, $row->password), 'Password should not verify');
    }

    public function testLoginFailsWithNonExistentEmail()
    {
        $email = 'notfound@example.com';

        // Simulate login
        $row = $this->userModel->select_single_row_data(['email' => $email]);
        $this->assertFalse($row, 'User should not exist');
    }
}
