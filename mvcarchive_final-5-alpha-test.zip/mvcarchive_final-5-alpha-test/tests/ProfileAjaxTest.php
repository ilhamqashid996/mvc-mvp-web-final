<?php
if (!defined('ROOT')) define('ROOT', 'http://localhost');
if (!defined('ROOTPATH')) define('ROOTPATH', __DIR__ . '/../');
if (!defined('DBHOST')) define('DBHOST', 'localhost');
if (!defined('DBUSER')) define('DBUSER', 'root');
if (!defined('DBPASS')) define('DBPASS', '');
if (!defined('DBNAME')) define('DBNAME', 'db_archive3_test2'); // ganti sesuai database test

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../app/core/functions.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Model.php';
require_once __DIR__ . '/../app/core/Controller.php';
require_once __DIR__ . '/../app/models/Image.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Post.php';
require_once __DIR__ . '/../app/models/Session.php';
require_once __DIR__ . '/../app/models/Request.php';
require_once __DIR__ . '/../app/controllers/Profile.php';
require_once __DIR__ . '/../app/controllers/Ajax.php';

class ProfileAjaxTest extends TestCase
{
    protected function setUp(): void
    {
        // Bersihkan database test
        $post = new \Model\Post();
        $user = new \Model\User();
        $post->run_query("DROP TABLE IF EXISTS posts");
        $user->run_query("DROP TABLE IF EXISTS users");
        $post->create_table();
        $user->create_table();
    }

    public function testCreatePostViaAjax()
    {
        // 1. Setup user dummy
        $user = new \Model\User();
        $user->insert([
            'username' => 'testuser',
            'email' => 'test@test.com',
            'password' => password_hash('123456', PASSWORD_DEFAULT),
            'date' => date("Y-m-d H:i:s")
        ]);
        $testUser = $user->select_single_row_data(['email' => 'test@test.com']);
        $this->assertNotFalse($testUser, "Test user should be created");
        
        // 2. Setup session login
        $_SESSION['USER'] = (object)[
            'id' => $testUser->id,
            'username' => 'testuser'
        ];

        // 3. Setup POST request
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['data_type'] = 'create-post';
        $_POST['post'] = 'Test Post Content';
        $_POST['description'] = 'Test Description';
        $_POST['price'] = '99999';
        $_FILES['image'] = [
            'name' => '',
            'error' => 1 // Simulasi tanpa image
        ];

        // 4. Jalankan Ajax controller
        ob_start();
        $ajax = new \Controller\Ajax();
        $ajax->index();
        $output = ob_get_clean();

        // 5. Verifikasi response JSON
        $response = json_decode($output);
        $this->assertTrue($response->success);
        $this->assertEquals('create-post', $response->data_type);

        // 6. Verifikasi data tersimpan di database
        $post = new \Model\Post();
        $saved = $post->select_single_row_data([
            'user_id' => $testUser->id,
            'post' => 'Test Post Content'
        ]);
        $this->assertNotFalse($saved);
        $this->assertEquals('Test Description', $saved->description);
        $this->assertEquals('99999', $saved->price);
    }

    protected function tearDown(): void 
    {
        $_SESSION = [];
        $_POST = [];
        $_FILES = [];
    }
}
