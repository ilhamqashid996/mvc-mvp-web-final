<?php
define('ROOTPATH', realpath(__DIR__ . '/../'));
