<?php
define('DBHOST', 'localhost');
define('DBNAME', 'db_archive3_test'); // Ganti dengan nama database test kamu
define('DBUSER', 'root'); // Ganti sesuai user MySQL kamu
define('DBPASS', ''); 
