<?php
if (!defined('ROOT')) define('ROOT', 'http://localhost'); // atau sesuai kebutuhan
    use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../app/core/functions.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Model.php';
require_once __DIR__ . '/../app/core/Controller.php';
require_once __DIR__ . '/../app/models/User.php';
require_once __DIR__ . '/../app/models/Post.php';
require_once __DIR__ . '/../app/models/Session.php';
require_once __DIR__ . '/../app/controllers/Home.php';

class HomeTestable extends \Controller\Home {
    public $sessionMock;
    public $userMock;
    public $postMock;
    public function index()
    {
        $session = $this->sessionMock;
        if (!$session->is_logged_in()) {
            redirect('login');
        }
        $id = 1; // user('id')
        $user = $this->userMock;
        $data['row'] = $row = $user->select_single_row_data(['id' => $id]);
        if ($data['row']) {
            $post = $this->postMock;
            $data['posts'] = $post->find_all();
            if ($data['posts']) {
                $data['posts'] = $post->add_user_data($data['posts']);
            }
        }
        $this->view('home', $data);
    }
}

class HomeTest extends TestCase
{
    public function testHomeViewWithPostsWhenLoggedIn()
    {
        // Mock Session agar dianggap sudah login
        $mockSession = $this->getMockBuilder(\Core\Session::class)
            ->onlyMethods(['is_logged_in'])
            ->getMock();
        $mockSession->method('is_logged_in')->willReturn(true);

        // Mock User model
        $mockUser = $this->getMockBuilder(\Model\User::class)
            ->onlyMethods(['select_single_row_data'])
            ->getMock();
        $mockUser->method('select_single_row_data')->willReturn((object)[
            'id' => 1,
            'username' => 'testuser',
            'image' => null
        ]);

        // Mock Post model
        $mockPost = $this->getMockBuilder(\Model\Post::class)
            ->onlyMethods(['find_all', 'add_user_data'])
            ->getMock();
        $mockPosts = [
            (object)[
                'id' => 1,
                'user_id' => 1,
                'post' => 'Test Post',
                'description' => 'Desc',
                'price' => 1000,
                'image' => null,
                'date' => date('Y-m-d H:i:s'),
                'user' => (object)['id'=>1, 'username'=>'testuser', 'image'=>null]
            ]
        ];
        $mockPost->method('find_all')->willReturn($mockPosts);
        $mockPost->method('add_user_data')->willReturn($mockPosts);

        // Mock Home controller dan override method view
        $home = $this->getMockBuilder(HomeTestable::class)
            ->onlyMethods(['view'])
            ->getMock();
        $home->sessionMock = $mockSession;
        $home->userMock = $mockUser;
        $home->postMock = $mockPost;

        $home->expects($this->once())
            ->method('view')
            ->with(
                $this->equalTo('home'),
                $this->callback(function($data) use ($mockPosts) {
                    return isset($data['posts']) && $data['posts'] === $mockPosts;
                })
            );

        $home->index();
    }
}
