<?php
if (!defined('ROOTPATH')) {
    define('ROOTPATH', realpath(__DIR__ . '/../'));
}

require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Model.php'; 
require_once __DIR__ . '/../app/models/User.php';

use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    public function testUserValidationFailsWhenFieldsAreEmpty()
    {
        $user = new \Model\User();
        $data = [
            'email' => '',
            'username' => '',
            'password' => '',
            'terms' => ''
        ];
        $result = $user->validate($data);
        $this->assertFalse($result);
        $this->assertArrayHasKey('email', $user->errors);
        $this->assertArrayHasKey('username', $user->errors);
        $this->assertArrayHasKey('password', $user->errors);
        $this->assertArrayHasKey('terms', $user->errors);
    }

    public function testUserValidationFailsWithInvalidEmail()
    {
        $user = new \Model\User();
        $data = [
            'email' => 'invalid-email',
            'username' => 'validusername',
            'password' => 'secret',
            'terms' => 'on'
        ];
        $result = $user->validate($data);
        $this->assertFalse($result);
        $this->assertArrayHasKey('email', $user->errors);
    }

    public function testUserValidationFailsWithInvalidUsername()
    {
        $user = new \Model\User();
        $data = [
            'email' => 'user@example.com',
            'username' => 'user 123',
            'password' => 'secret',
            'terms' => 'on'
        ];
        $result = $user->validate($data);
        $this->assertFalse($result);
        $this->assertArrayHasKey('username', $user->errors);
    }

    public function testUserValidationSuccess()
    {
        $user = new \Model\User();
        $data = [
            'email' => 'user@example.com',
            'username' => 'username',
            'password' => 'secret',
            'terms' => 'on'
        ];
        $result = $user->validate($data);
        $this->assertTrue($result);
        $this->assertEmpty($user->errors);
    }
}
