<?php

namespace Controller;

defined('ROOTPATH') OR exit('Access Denied!');

use \Model\User;
use \Core\Request;

class Signup
{
    use MainController;

    public function index()
    {
        // Mulai hitung waktu & memori
        $start_time = microtime(true);
        $start_memory = memory_get_usage();

        $data = [];
        $request = new Request;

        if ($request->posted())
        {
            $user = new User;

            // Check if user data validated
            if ($user->validate($request->post()))
            {
                // Save to database
                $password = password_hash($request->post('password'), PASSWORD_DEFAULT);
                $request->set('password', $password);
                $request->set('date', date("Y-m-d H:i:s"));
                
                $user->insert($request->post());

                // Hitung waktu & memori setelah proses signup
                $end_time = microtime(true);
                $end_memory = memory_get_usage();

                $data['execution_time'] = $end_time - $start_time;
                $data['memory_usage'] = $end_memory - $start_memory;

                // redirect('login');
            }
            else
            {
                // Jika validasi gagal atau halaman pertama kali dibuka
                $end_time = microtime(true);
                $end_memory = memory_get_usage();
                $data['execution_time'] = $end_time - $start_time;
                $data['memory_usage'] = $end_memory - $start_memory;

                $data['errors'] = $user->errors;
            }
        }

        $this->view('signup', $data);
    }
}
