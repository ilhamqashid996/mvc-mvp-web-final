<?php

namespace Controller;

defined('ROOTPATH') OR exit('Access Denied!');

use \Model\User;
use \Core\Request;
use \Core\Session;

class Login
{
    use MainController;

    public function index()
    {
        // Mulai hitung waktu dan memori
        $start_time = microtime(true);
        $start_memory = memory_get_usage();

        $data = [];
        $request = new Request;

        if ($request->posted())
        {
            $user = new User;

            $email = $request->post('email');
            $password = $request->post('password');

            // Check if user data is available
            if ($row_data = $user->select_single_row_data(['email' => $email]))
            {
                // Check is password is correct
                if (password_verify($password, $row_data->password))
                {
                    $session = new Session;
                    $session->auth($row_data);

                    // Hitung waktu dan memori setelah login berhasil
                    $end_time = microtime(true);
                    $end_memory = memory_get_usage();

                    $data['execution_time'] = $end_time - $start_time;
                    $data['memory_usage'] = $end_memory - $start_memory;

                    redirect('home');
                }
                else
                {
                    $user->errors['email'] = "Incorrect email or password. Try again.";
                    $data['errors'] = $user->errors;
                }
            }
        }

        $this->view('login', $data);
    }
}
