<?php
$this->view('header')
?>

<h1 class="p-3 text-center">HOME PAGE</h1>

<div class="row p-2 col-md-8 shadow mx-auto border rounded">
    <div class="col-md-3 text-center d-none">
        <a href="<?=ROOT?>/profile/<?=$row->id?>">
            <span>
                <img class="profile-image rounded-circle m-4" src="<?=get_image($row->image)?>" style="width: 100px; height: 100px; object-fit: cover;">
            </span>
            <h5><?=esc($row->username)?></h5>
        </a>
    </div>

    <div class="col-md-12 my-3">
        <?php if (!empty($posts)): ?>
            <?php foreach($posts as $post): ?>
                <?php
                $this->view('post-small', ['post' => $post]);
                ?>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">Tidak ada data</p>
        <?php endif; ?>
    </div>
</div>

<?php
$execution_time = $end_time - ($start_time ?? 0);
$memory_usage = $end_memory - ($start_memory ?? 0);
?>

<div class="alert alert-info text-center mt-3">
    Waktu eksekusi: <?= round($execution_time, 5) ?> detik<br>
    Penggunaan memori: <?= formatMemory($memory_usage) ?>
</div>

<?php
$this->view('footer')
?>
