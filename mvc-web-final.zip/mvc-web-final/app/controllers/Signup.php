<?php

namespace Controller;

defined('ROOTPATH') OR exit('Access Denied!');

class Signup
{
    use MainController;

    public function index()
    {
        $this->view('signup');
    }
}
