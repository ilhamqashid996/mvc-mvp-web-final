<?php
require_once '../app/models/User.php';
require_once '../app/models/Post.php';

// Ambil user_id dari URL atau session
$id = null;
if (isset($_GET['url'])) {
    $url = explode('/', trim($_GET['url'], '/'));
    $id = $url[1] ?? null;
}
if (!$id) {
    $id = user('id');
}

// Ambil data user
$userModel = new \Model\User();
$row = $userModel->select_single_row_data(['id' => $id]);

// Ambil data post berdasarkan user_id
$postModel = new \Model\Post();
$posts = $postModel->find_data(['user_id' => $id]);
if ($posts) {
    $posts = $postModel->add_user_data($posts);
}

require_once '../app/views/header.view.php';
?>

<h1 class="p-3 text-center">USER PROFILE</h1>

<div class="p-3 col-md-6 shadow mx-auto border rounded">
    <div class="text-center">
        <span>
            <img class="profile-image rounded-circle m-4" src="<?=get_image($row->image)?>" style="width: 200px; height: 200px; object-fit: cover;">
            <?php if (user('id') == $row->id): ?>
            <label>
                <i style="position: absolute; cursor: pointer;" class="h2 text-primary bi bi-image"></i>
                <input onchange="display_image(this.files[0])" type="file" class="d-none">
            </label>
            <?php endif; ?>
        </span>
        <div class="profile-image-prog progress d-none">
            <div class="progress-bar" style="width: 0%;">0%</div>
        </div>
        <h2><?=esc($row->username)?></h2>
        <script>
            function display_image(file)
            {
                let allowed = ['jpg','jpeg','png','webp'];
                let ext = file.name.split(".").pop();

                if (!allowed.includes(ext.toLowerCase()))
                {
                    alert('Only files of this type allowed: ' + allowed.toString(", "));
                    return;
                }

                document.querySelector(".profile-image").src = URL.createObjectURL(file);
                change_image(file);
            }

            function display_post_image(file)
            {
                let allowed = ['jpg','jpeg','png','webp'];
                let ext = file.name.split(".").pop();

                if (!allowed.includes(ext.toLowerCase()))
                {
                    alert('Only files of this type allowed: ' + allowed.toString(", "));
                    post_image_added = false;
                    return;
                }

                document.querySelector(".post-image").src = URL.createObjectURL(file);
                document.querySelector(".post-image").parentNode.classList.remove("d-none");

                post_image_added = true;
            }
        </script>
    </div><hr>
    <?php if (user('id') == $row->id): ?>
    <div>
        <form method="post" onsubmit="submit_post(event)">
            <div class="bg-secondary p-1">
                <textarea id="post-input" rows="2" class="form-control" placeholder="Enter your post here..."></textarea>
                <textarea id="description-input" rows="6" class="form-control" placeholder="Enter description..."></textarea>
                <textarea id="price-input" rows="1" class="form-control" placeholder="Enter price... (in number)"></textarea>
                <label>
                    <i style="cursor: pointer;" class="h2 text-white bi bi-image"></i>
                    <input id="post-image-input" onchange="display_post_image(this.files[0])" type="file" class="d-none">
                </label>
                <button class="mt-1 btn btn-warning float-end">Send</button>
                <div class="text-center d-none">
                    <img class="post-image m-1" src="" style="width: 100px; height: 100px; object-fit: cover;">
                </div>
                
                <div class="clearfix"></div>
            </div>
        </form>
        <div class="post-prog progress d-none">
            <div class="progress-bar" style="width: 0%;">0%</div>
        </div>
    </div><hr>
    <?php endif; ?>

    <div class="my-3">
        <?php if (!empty($posts)): ?>
            <?php foreach($posts as $post): ?>
                <div class="row post p-1">
                    <div class="col-3 bg-light text-center">
                        <a href="<?=ROOT?>/profile/<?=$post->user->id?>">
                            <img class="profile-image rounded-circle m-1" src="<?=get_image($post->user->image ?? '')?>" style="width: 80px; height: 80px; object-fit: cover;">
                            <h5><?=esc($post->user->username ?? 'Unknown')?></h5>
                        </a>
                    </div>
                    <div class="col-9 text-start">
                        <div class="muted p-1"><?=get_date($post->date)?></div>
                        <?php if(!empty($post->image)): ?>
                            <a href="<?=ROOT?>/post/<?=$post->id?>">
                                <img class="my-1" src="<?=get_image($post->image)?>" style="width: 200px; height: 200px; object-fit: cover;">
                            </a>
                        <?php endif; ?>
                        <p><b><?=esc($post->post)?></b></p>
                        <?php if(!empty($post->price)): ?>
                            <p>Harga: <b>Rp. <?=esc($post->price)?>,00</b></p>
                        <?php else: ?>
                            <p>Harga: <b>Rp. 0,00</b></p>
                        <?php endif; ?>
                        <div class="d-none">
                            <?php if (user('id') == $post->user_id): ?>        
                                <a href="<?=ROOT?>/post/edit/<?=$post->id?>">
                                    <button class="btn-sm m-1 btn btn-warning">Edit</button>
                                </a>
                                <a href="<?=ROOT?>/post/delete/<?=$post->id?>">
                                    <button class="btn-sm m-1 btn btn-danger">Delete</button>
                                </a>
                            <?php endif; ?>
                        </div>
                        <div>
                            <a href="<?=ROOT?>/post/<?=$post->id?>">
                                <button class="btn-sm m-1 btn btn-primary">Show Post</button>
                            </a>
                        </div>
                    </div>
                </div><hr>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">Tidak ada data</p>
        <?php endif; ?>        
    </div>
</div>
<script>
    var post_image_added = false;

    function change_image(file)
    {
        var obj = {};
        obj.image = file;
        obj.data_type = "profile-image";
        obj.id = "<?=user('id')?>";
        obj.progressbar = 'profile-image-prog';

        send_data(obj);
    }

    function submit_post(e)
    {
        e.preventDefault();
        
        var obj = {};

        if (post_image_added)
        {
            obj.image = e.currentTarget.querySelector("#post-image-input").files[0];
        }
        
        obj.post = e.currentTarget.querySelector("#post-input").value;
        obj.description = e.currentTarget.querySelector("#description-input").value;
        obj.price = e.currentTarget.querySelector("#price-input").value;
        obj.data_type = "create-post";
        obj.id = "<?=user('id')?>";
        obj.progressbar = 'post-prog';

        send_data(obj);
    }
    
    function send_data(obj)
    {
        var my_form = new FormData();
        var progressbar = null;

        if (typeof obj.progressbar != 'undefined')
        {
            progressbar = document.querySelector("." + obj.progressbar);
        }

        for (key in obj)
        {
            my_form.append(key,obj[key]);
        }
        
        var ajax = new XMLHttpRequest();
        ajax.addEventListener('readystatechange',function(e){
            if (ajax.readyState == 4 && ajax.status == 200)
            {
                handle_result(ajax.responseText);
            }
        });

        if (progressbar)
        {
            progressbar.classList.remove("d-none");

            progressbar.children[0].style.width = "0%";
            progressbar.children[0].innerHTML = "0%";

            ajax.upload.addEventListener('progress',function(e){
                let percent = Math.round((e.loaded / e.total) * 100);
                progressbar.children[0].style.width = percent + "%";
                progressbar.children[0].innerHTML = percent + "%";
            });
        }

        ajax.open('post','<?=ROOT?>/ajax',true);
        ajax.send(my_form);
    }

    function handle_result(result)
    {
        let obj = JSON.parse(result);

        if (obj.data_type == "profile-image")
        {
            alert(obj.message);
            window.location.reload();
        }
        else if (obj.data_type == "create-post")
        {
            alert(obj.message);
            window.location.reload();
        }
        // console.log(result);
    }
</script>

<?php
require_once '../app/views/footer.view.php';
?>
